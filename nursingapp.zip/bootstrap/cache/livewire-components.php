<?php return array (
  'add-new-blood-pressure-reading-form' => 'App\\Http\\Livewire\\AddNewBloodPressureReadingForm',
  'add-new-patient-form' => 'App\\Http\\Livewire\\AddNewPatientForm',
  'blood-pressure-reading-table' => 'App\\Http\\Livewire\\BloodPressureReadingTable',
  'patient-table' => 'App\\Http\\Livewire\\PatientTable',
);