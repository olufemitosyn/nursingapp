<div>
    <?php if($dumpFilters): ?>
        <?php dump($filters); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\vendor\rappasoft\laravel-livewire-tables\src\/../resources/views/includes/debug.blade.php ENDPATH**/ ?>