<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('AFJQ1Nx')) {
    $componentId = $_instance->getRenderedChildComponentId('AFJQ1Nx');
    $componentTag = $_instance->getRenderedChildComponentTagName('AFJQ1Nx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AFJQ1Nx');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('AFJQ1Nx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>