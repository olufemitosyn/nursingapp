<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Show Patient
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 uppercase font-semibold">
                    Patient Info
                </div>
                <div class="p-6 bg-white border-b border-gray-200 flex justify-around">
                    <div>
                        <div>First Name</div>
                        <div class="text-2xl"><?php echo e($patient->first_name); ?></div>
                    </div>
                    <div>
                        <div>Last Name</div>
                        <div class="text-2xl"><?php echo e($patient->last_name); ?></div>
                    </div>
                    <div>
                        <div>Sex</div>
                        <div class="text-2xl"><?php echo e($patient->sex); ?></div>
                    </div>
                    <div>
                        <div>Birth Date</div>
                        <div class="text-2xl"><?php echo e($patient->birth_date); ?></div>
                    </div>
                    <div class="w-2/6">
                        <div>Address</div>
                        <div class="text-xl"><?php echo e($patient->address); ?></div>
                    </div>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mt-10">
                <div x-data="{ showAddNewForm: false }" @form-canceled.window="showAddNewForm = false">
                    <div class="p-6 bg-white border-b border-gray-200 uppercase font-semibold flex justify-between">
                        <div>
                            Patient Blood Pressure Readings
                        </div>
                        <div clas>
                            <button class="bg-gray-700 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded" @click="showAddNewForm = true">Add New Reading</button>
                        </div>
                    </div>
                    <div x-show="showAddNewForm">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-new-blood-pressure-reading-form', ['patientId' => $patient->id])->html();
} elseif ($_instance->childHasBeenRendered('9BtyMJG')) {
    $componentId = $_instance->getRenderedChildComponentId('9BtyMJG');
    $componentTag = $_instance->getRenderedChildComponentTagName('9BtyMJG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9BtyMJG');
} else {
    $response = \Livewire\Livewire::mount('add-new-blood-pressure-reading-form', ['patientId' => $patient->id]);
    $html = $response->html();
    $_instance->logRenderedChild('9BtyMJG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="p-6 bg-white border-b border-gray-200">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blood-pressure-reading-table', ['patientId' => $patient->id])->html();
} elseif ($_instance->childHasBeenRendered('KRuG1bU')) {
    $componentId = $_instance->getRenderedChildComponentId('KRuG1bU');
    $componentTag = $_instance->getRenderedChildComponentTagName('KRuG1bU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KRuG1bU');
} else {
    $response = \Livewire\Livewire::mount('blood-pressure-reading-table', ['patientId' => $patient->id]);
    $html = $response->html();
    $_instance->logRenderedChild('KRuG1bU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\resources\views/show-patient.blade.php ENDPATH**/ ?>