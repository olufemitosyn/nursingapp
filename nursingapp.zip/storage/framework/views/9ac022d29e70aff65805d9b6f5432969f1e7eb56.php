<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div x-data="{ showAddNewForm: false }" @form-canceled.window="showAddNewForm = false">
                    <div class="p-6 bg-white border-b border-gray-200 uppercase font-semibold flex justify-between">
                        <div>
                            All Patients
                        </div>
                        <div clas>
                            <button class="bg-gray-700 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded" @click="showAddNewForm = true">Add New Patient</button>
                        </div>
                    </div>
                    <div x-show="showAddNewForm">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-new-patient-form', [])->html();
} elseif ($_instance->childHasBeenRendered('0PgCRZ6')) {
    $componentId = $_instance->getRenderedChildComponentId('0PgCRZ6');
    $componentTag = $_instance->getRenderedChildComponentTagName('0PgCRZ6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0PgCRZ6');
} else {
    $response = \Livewire\Livewire::mount('add-new-patient-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('0PgCRZ6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('patient-table', [])->html();
} elseif ($_instance->childHasBeenRendered('Y2FgpM2')) {
    $componentId = $_instance->getRenderedChildComponentId('Y2FgpM2');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y2FgpM2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y2FgpM2');
} else {
    $response = \Livewire\Livewire::mount('patient-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('Y2FgpM2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\resources\views/dashboard.blade.php ENDPATH**/ ?>