<div class="flex flex-col items-center">
    <div class="w-6/12">
        <form method="POST" wire:submit.prevent="submit">
            <?php echo csrf_field(); ?>
            <div class="m-5">
                <label for="first-name" class="block">First Name</label>
                <input id="first-name" wire:model="firstName" class="block w-full rounded" type="text" value="<?php echo e(old('firstName')); ?>" required/>
                <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="m-5">
                <label for="last-name" class="block">Last Name</label>
                <input id="last-name" wire:model="lastName" class="block w-full rounded" type="text" value="<?php echo e(old('lastName')); ?>" required/>
                <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="m-5">
                <label for="sex" class="block">Sex</label>
                <div>
                    <label for="sex">Male</label>
                    <input id="sex" wire:model="sex" type="radio" value="Male"/>
                    <label for="sex">Female</label>
                    <input id="sex" wire:model="sex" type="radio" value="Female"/>
                </div>
                <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="m-5">
                <label for="birth-date" class="block">Date of Birth</label>
                <input id="birth-date" wire:model="birthDate" class="block w-full rounded" type="date" value="<?php echo e(old('birthDate')); ?>"/>
                <?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="m-5">
                <label for="address" class="block">Address</label>
                <input id="address" wire:model="address" class="block w-full rounded" type="text" value="<?php echo e(old('address')); ?>"/>
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="m-5 flex justify-end">
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mx-2" type="submit">Save</button>
                <button class="bg-gray-200 hover:bg-gray-300 text-gray-900 font-bold py-2 px-4 rounded" wire:click="cancelForm" type="button">Cancel</button>
            </div>
            <div wire:loading wire:target="submit">
                Creating ... <br> You will be redirected to the Login Page when all is done.
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\resources\views/livewire/add-new-patient-form.blade.php ENDPATH**/ ?>