<div class="flex flex-col items-center">
    <div class="w-6/12">
        <form method="POST" wire:submit.prevent="submit">
            <?php echo csrf_field(); ?>
            <div class="flex justify-between">
                <div class="m-5">
                    <label for="systolic" class="block">Systolic</label>
                    <input id="systolic" wire:model="systolic" class="block w-full rounded" type="number" value="<?php echo e(old('systolic')); ?>" required/>
                    <?php $__errorArgs = ['systolic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-600">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="m-5">
                    <label for="diastolic" class="block">Diastolic</label>
                    <input id="diastolic" wire:model="diastolic" class="block w-full rounded" type="number" value="<?php echo e(old('diastolic')); ?>" required/>
                    <?php $__errorArgs = ['diastolic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-600">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="m-5">
                <label for="observation-datetime" class="block">Observation Datetime</label>
                <input id="observation-datetime" wire:model="observationDatetime" class="block w-full rounded" type="datetime-local"/>
                <?php $__errorArgs = ['observationDatetime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="m-5">
                <label for="observation-note" class="block">Observation Note</label>
                <textarea id="observation-note" wire:model="observationNote" class="block w-full rounded">

                </textarea>
                <?php $__errorArgs = ['observationNote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-600">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="m-5 flex justify-end">
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mx-2" type="submit">Save</button>
                <button class="bg-gray-200 hover:bg-gray-300 text-gray-900 font-bold py-2 px-4 rounded" wire:click="cancelForm" type="button">Cancel</button>
            </div>
            <div wire:loading wire:target="submit">
                Creating ... <br> You will be redirected to the Login Page when all is done.
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\web\patient-blood-pressure-mrs\resources\views/livewire/add-new-blood-pressure-reading-form.blade.php ENDPATH**/ ?>